package trilaterationPackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class TrilateratorTest {

	@Test
	public void test1() {
		test(new Vector(0,0),new Vector(0,10),new Vector(8,0),new Vector (5,5),1);
		test(new Vector(0,0),new Vector(0,10),new Vector(8,0),new Vector (0,2),3);
		test(new Vector(0,0),new Vector(0,10),new Vector(8,0),new Vector (10,10),3);
		test(new Vector(0,0),new Vector(0,10),new Vector(5,7),new Vector (0,2),3);
		test(new Vector(0,0),new Vector(0,10),new Vector(5,7),new Vector (0,10),0);
	}
	
	private void test(Vector A, Vector B, Vector C, Vector P, double h)
	{
		double dA = dis(A,P,h);
		double dB = dis(B,P,h);
		double dC = dis(C,P,h);
		Vector Q = Trilaterator.trilaterate(A, dA, B, dB, C, dC);
		assertTrue(P.equals(Q));
	}
	
	private double dis(Vector F, Vector P, double h)
	{
		Vector r = P.minus(F);
		return Math.sqrt(Math.pow(r.x, 2)+Math.pow(r.y, 2)+Math.pow(h, 2));
	}
}
