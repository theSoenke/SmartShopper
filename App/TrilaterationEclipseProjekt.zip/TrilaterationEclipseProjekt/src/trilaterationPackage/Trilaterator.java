package trilaterationPackage;

public class Trilaterator
{
	public static Vector trilaterate(Vector A, double dA, Vector B, double dB, Vector C, double dC)
	{
		Vector v = B.minus(A);
		double y = Math.pow(dA, 2)/(2*v.laenge)-Math.pow(dB, 2)/(2*v.laenge)+v.laenge/2;
		Vector r = v.mal(y/v.laenge);
		Vector w = new Vector(-v.y,v.x);
		double t = (Math.pow(dC, 2)-Math.pow(dA, 2)-Math.pow(C.x, 2)+Math.pow(A.x, 2)-Math.pow(C.y, 2)+Math.pow(A.y, 2)-r.x*2*(A.x-C.x)-r.y*2*(A.y-C.y))/(2*(w.x*(A.x-C.x)+w.y*(A.y-C.y)));
		return r.plus(w.mal(t));
	}
}
